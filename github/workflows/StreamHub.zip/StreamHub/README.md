# StreamHub

Open in Android Studio (Koala or newer) -> Sync -> Run.

## Repository format
repo.json
{"name":"My Repo","sources":[{"name":"My Server","url":"https://example.com/catalog.json"}]}

catalog.json
{"items":[{"title":"Sample","poster":"https://example.com/p.jpg","url":"https://example.com/video.mp4"}]}

Use only content you own or are licensed to stream.
