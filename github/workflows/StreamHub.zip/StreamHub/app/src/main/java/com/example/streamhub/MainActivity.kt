package com.example.streamhub

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import java.io.File

class AppVM(app: Application) : AndroidViewModel(app) {
    private val store = RepoStore(app)
    val repos = mutableStateListOf<Repo>()
    val items = mutableStateListOf<VideoItem>()
    var selected by mutableStateOf<SourceRef?>(null)
    var message by mutableStateOf<String?>(null)
    var loading by mutableStateOf(false)

    init { refreshRepos() }

    fun refreshRepos() = viewModelScope.launch {
        repos.clear()
        store.urls().forEach { u ->
            runCatching { parseRepo(u, Net.get(u)) }
                .onSuccess { repos.add(it) }
                .onFailure { message = "Repo load failed: $u" }
        }
    }

    fun addRepo(url: String) = viewModelScope.launch {
        val u = url.trim()
        runCatching { parseRepo(u, Net.get(u)) }
            .onSuccess { store.add(u); repos.add(it) }
            .onFailure { message = "Invalid repository URL or JSON" }
    }

    fun removeRepo(r: Repo) { store.remove(r.url); repos.remove(r) }

    fun open(s: SourceRef?) {
        selected = s
        items.clear()
        if (s == null) return
        viewModelScope.launch {
            loading = true
            runCatching { parseCatalog(Net.get(s.url)) }
                .onSuccess { items.addAll(it) }
                .onFailure { message = "Source load failed" }
            loading = false
        }
    }

    fun download(ctx: Context, v: VideoItem) {
        WorkManager.getInstance(ctx).enqueue(
            OneTimeWorkRequestBuilder<DownloadWorker>()
                .setInputData(workDataOf("url" to v.url, "title" to v.title)).build()
        )
        message = "Download started: ${v.title}"
    }
}

fun play(ctx: Context, url: String) =
    ctx.startActivity(Intent(ctx, PlayerActivity::class.java).putExtra("url", url))

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { App() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(vm: AppVM = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(vm.message) { vm.message?.let { snack.showSnackbar(it); vm.message = null } }
    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Default.Home, null) }, label = { Text("Browse") })
                NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Default.Storage, null) }, label = { Text("Repositories") })
                NavigationBarItem(tab == 2, { tab = 2 }, { Icon(Icons.Default.Download, null) }, label = { Text("Downloads") })
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> BrowseScreen(vm)
                1 -> RepoScreen(vm)
                else -> DownloadsScreen()
            }
        }
    }
}

@Composable
fun BrowseScreen(vm: AppVM) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val sel = vm.selected
    if (sel == null) {
        val all = vm.repos.flatMap { r -> r.sources.map { r.name to it } }
        if (all.isEmpty()) Text("No sources yet. Add a repository in the Repositories tab.", Modifier.padding(16.dp))
        LazyColumn {
            items(all) { (repo, s) ->
                ListItem(
                    headlineContent = { Text(s.name) },
                    supportingContent = { Text(repo) },
                    modifier = Modifier.clickable { vm.open(s) }
                )
            }
        }
    } else {
        Column {
            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton({ vm.open(null) }) { Icon(Icons.Default.ArrowBack, null) }
                Text(sel.name, style = MaterialTheme.typography.titleMedium)
            }
            if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth())
            LazyColumn {
                items(vm.items) { v ->
                    ListItem(
                        leadingContent = { v.poster?.let { AsyncImage(it, null, Modifier.size(56.dp)) } },
                        headlineContent = { Text(v.title) },
                        trailingContent = {
                            IconButton({ vm.download(ctx, v) }) { Icon(Icons.Default.Download, null) }
                        },
                        modifier = Modifier.clickable { play(ctx, v.url) }
                    )
                }
            }
        }
    }
}

@Composable
fun RepoScreen(vm: AppVM) {
    var url by remember { mutableStateOf("") }
    Column(Modifier.padding(16.dp)) {
        OutlinedTextField(url, { url = it }, Modifier.fillMaxWidth(), label = { Text("Repository URL (repo.json)") }, singleLine = true)
        Button({ if (url.isNotBlank()) { vm.addRepo(url); url = "" } }, Modifier.padding(top = 8.dp)) { Text("Add repository") }
        LazyColumn(Modifier.padding(top = 8.dp)) {
            items(vm.repos.toList()) { r ->
                ListItem(
                    headlineContent = { Text(r.name) },
                    supportingContent = { Text("${r.sources.size} sources · ${r.url}") },
                    trailingContent = { IconButton({ vm.removeRepo(r) }) { Icon(Icons.Default.Delete, null) } }
                )
            }
        }
    }
}

@Composable
fun DownloadsScreen() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var files by remember { mutableStateOf(listFiles(ctx)) }
    if (files.isEmpty()) Text("No downloads yet.", Modifier.padding(16.dp))
    LazyColumn {
        items(files) { f ->
            ListItem(
                headlineContent = { Text(f.nameWithoutExtension) },
                trailingContent = {
                    IconButton({ f.delete(); files = listFiles(ctx) }) { Icon(Icons.Default.Delete, null) }
                },
                modifier = Modifier.clickable { play(ctx, Uri.fromFile(f).toString()) }
            )
        }
    }
}

private fun listFiles(ctx: Context): List<File> =
    File(ctx.filesDir, "downloads").listFiles { f -> f.extension == "mp4" }?.toList() ?: emptyList()
