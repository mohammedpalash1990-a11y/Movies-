package com.example.streamhub

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.URL

class DownloadWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val url = inputData.getString("url") ?: return@withContext Result.failure()
        val title = inputData.getString("title") ?: "video"
        val dir = File(applicationContext.filesDir, "downloads").apply { mkdirs() }
        val out = File(dir, title.replace(Regex("[^A-Za-z0-9._-]"), "_") + ".mp4")
        val tmp = File(dir, out.name + ".part")
        try {
            URL(url).openStream().use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            tmp.renameTo(out)
            Result.success()
        } catch (e: Exception) {
            tmp.delete()
            Result.retry()
        }
    }
}
