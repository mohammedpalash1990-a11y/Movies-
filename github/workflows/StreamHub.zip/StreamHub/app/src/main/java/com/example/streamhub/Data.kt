package com.example.streamhub

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL

data class SourceRef(val name: String, val url: String)
data class Repo(val url: String, val name: String, val sources: List<SourceRef>)
data class VideoItem(val title: String, val poster: String?, val url: String)

object Net {
    suspend fun get(url: String): String = withContext(Dispatchers.IO) {
        URL(url).openStream().bufferedReader().use { it.readText() }
    }
}

/** repo.json: {"name":"My Repo","sources":[{"name":"X","url":"https://.../catalog.json"}]} */
fun parseRepo(url: String, text: String): Repo {
    val o = JSONObject(text)
    val arr = o.optJSONArray("sources")
    val list = (0 until (arr?.length() ?: 0)).map {
        val s = arr!!.getJSONObject(it)
        SourceRef(s.getString("name"), s.getString("url"))
    }
    return Repo(url, o.optString("name", url), list)
}

/** catalog.json: {"items":[{"title":"..","poster":"..","url":"https://..mp4 or .m3u8"}]} */
fun parseCatalog(text: String): List<VideoItem> {
    val arr = JSONObject(text).optJSONArray("items") ?: return emptyList()
    return (0 until arr.length()).map {
        val s = arr.getJSONObject(it)
        VideoItem(s.getString("title"), s.optString("poster").ifBlank { null }, s.getString("url"))
    }
}

class RepoStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("repos", Context.MODE_PRIVATE)
    fun urls(): List<String> = sp.getStringSet("urls", emptySet())!!.toList().sorted()
    fun add(u: String) = sp.edit().putStringSet("urls", sp.getStringSet("urls", emptySet())!! + u).apply()
    fun remove(u: String) = sp.edit().putStringSet("urls", sp.getStringSet("urls", emptySet())!! - u).apply()
}
